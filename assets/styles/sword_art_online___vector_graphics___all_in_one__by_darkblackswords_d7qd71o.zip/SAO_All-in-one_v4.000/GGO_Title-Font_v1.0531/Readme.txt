This Font Software is licensed under the SIL Open Font License, Version 1.1.
This license is available with a FAQ at: http://scripts.sil.org/OFL

These "HomenajeMod" fonts are modified version of "Homenaje".
"Homenaje" font is not created by darkblackswords.
"HomenajeMod" fonts are modified by darkblackswords.

About "HomenajeBoB3"
This is for typing "Bullet of Bullets 3" only.
If you want to type other words for logo, please use "HomenajeMod_Logo".

About "HomenajeGGO"
This is for typing "Gun Gale Online" only.
If you want to type other words for logo, please use "HomenajeMod_Logo".

About "Another" version
This is for typing modified "t" and "l" (similar to GGO logo).
